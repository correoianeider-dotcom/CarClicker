const carView = {
    init() {
        this.carElem = document.getElementById('car');
        this.carNameElem = document.getElementById('car-name');
        this.carImageElem = document.getElementById('car-img');
        this.countElem = document.getElementById('car-count');

        this.carImageElem.addEventListener('click', this.handleClick);

        this.render();
    },

    handleClick() {
        controller.incrementCounter();
    },

    render() {
        const currentCar = controller.getCurrentCar();

        this.countElem.textContent = currentCar.clickCount;
        this.carNameElem.textContent = currentCar.name;
        this.carImageElem.src = currentCar.imgSrc;
        this.carImageElem.style.cursor = 'pointer';
    },
};