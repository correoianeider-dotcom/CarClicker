const controller = {
    init() {
        model.currentCar = model.cars[0];

        carListView.init();
        carView.init();
    },

    getCurrentCar() {
        return model.currentCar;
    },

    getCars() {
        return model.cars;
    },

    setCurrentCar(car) {
        model.currentCar = car;
    },

    incrementCounter() {
        model.currentCar.clickCount++;
        carView.render();
    },
};