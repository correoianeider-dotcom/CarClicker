const carListView = {
    init() {
        this.carListElem = document.getElementById('car-list');
        this.render();
    },

    render() {
        let car;
        let elem;

        const cars = controller.getCars();
        this.carListElem.innerHTML = '';

        for (let i = 0; i < cars.length; i++) {
            car = cars[i];

            elem = document.createElement('li');
            elem.className = 'list-group-item d-flex justify-content-between lh-condensed';
            elem.style.cursor = 'pointer';
            elem.textContent = car.name;

            elem.addEventListener(
                'click',
                (function (carCopy) {
                    return function () {
                        controller.setCurrentCar(carCopy);
                        carView.render();
                    };
                })(car)
            );

            this.carListElem.appendChild(elem);
        }
    },
};